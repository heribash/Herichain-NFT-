import React from 'react';
import { motion } from 'framer-motion';
import { LogOut, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/Logo';
import { ConnectButton } from 'thirdweb/react';
import { createWallet, walletConnect, inAppWallet } from 'thirdweb/wallets';
import { client } from '@/main';
import { polygonAmoy } from 'thirdweb/chains';

const Header = ({ user, onLogin, onSignup, onLogout }) => {

  const wallets = [
    inAppWallet({
      auth: {
        options: ["email"],
      },
    }),
    createWallet('io.metamask'),
    createWallet('com.coinbase.wallet'),
    walletConnect(),
    createWallet('me.rainbow'),
  ];

  return (
    <header className="bg-background/80 backdrop-blur-sm shadow-sm sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Logo />
          </motion.div>

          <nav className="flex items-center space-x-4">
            {user ? (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="flex items-center space-x-4"
              >
                <ConnectButton
                  client={client}
                  wallets={wallets}
                  chain={polygonAmoy}
                  connectButton={{
                    label: "Connect Vault",
                    style: {
                      backgroundColor: 'hsl(var(--secondary))',
                      color: 'hsl(var(--secondary-foreground))',
                      fontWeight: '600',
                    }
                  }}
                  theme="light"
                  connectModal={{
                    size: "compact",
                    title: "Connect Your Vault",
                    showThirdwebBranding: false,
                    networkSelector: {
                      title: "Network",
                      supportedNetworks: [polygonAmoy],
                    },
                    welcomeScreen: {
                      title: "Your Digital Legacy Vault",
                      subtitle: "Connect to archive on the Polygon Amoy Testnet."
                    }
                  }}
                  connectOptions={user.email ? {
                    strategy: "email",
                    email: user.email,
                  } : undefined}
                />
                <div className="hidden sm:flex items-center space-x-2 text-foreground/80">
                  <User className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">{user.name}</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onLogout}
                  className="flex items-center space-x-2 border-primary text-primary hover:bg-primary hover:text-accent-foreground"
                >
                  <LogOut className="h-4 w-4" />
                  <span className="hidden sm:inline">Logout</span>
                </Button>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="flex items-center space-x-3"
              >
                <Button variant="ghost" onClick={onLogin} className="text-foreground/80 hover:text-primary">
                  Login
                </Button>
                <Button 
                  onClick={onSignup}
                  className="bg-secondary hover:bg-taupe-hover text-secondary-foreground font-semibold"
                >
                  Get Started
                </Button>
              </motion.div>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
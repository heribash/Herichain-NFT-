import React from 'react';
import { motion } from 'framer-motion';
import { Copy, Share2, Twitter, Instagram, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const Referrals = ({ user }) => {
  const referralLink = `${window.location.origin}/?ref=${user.referralCode}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink);
    toast({
      title: 'Copied to Clipboard!',
      description: 'Your referral link is ready to be shared.',
    });
  };

  const shareOnTwitter = () => {
    const text = `Join me on Herichain to turn memories into eternal treasures! I get bonus mints if you sign up. #Herichain #NFT #DigitalLegacy`;
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(referralLink)}`;
    window.open(url, '_blank');
  };
  
  const shareOnInstagram = () => {
    toast({
      title: 'Share on Instagram',
      description: 'Copy your link and paste it in your Instagram bio or story!',
    });
    copyToClipboard();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-6 md:p-8"
    >
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground">Refer & Earn</h2>
        <p className="text-foreground/70 mt-2">
          Share your love for Herichain and earn bonus mints!
        </p>
      </div>

      <Card className="bg-gradient-to-br from-pink-100/20 via-yellow-100/20 to-rose-100/20 border-border shadow-lg">
        <CardHeader>
          <div className="flex items-center space-x-3">
            <Gift className="h-8 w-8 text-primary" />
            <CardTitle className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#D4AF37] to-pink-400">
              Share Your Invite Link
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-foreground/80">
            Share your link: Earn <span className="font-bold text-primary">30 bonus mints</span> when a friend registers! They'll get their own 10 free starter mints.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-2">
            <div className="w-full flex-grow p-3 bg-background border border-border rounded-lg text-foreground/80 overflow-x-auto font-mono">
              {referralLink}
            </div>
            <Button
              onClick={copyToClipboard}
              size="lg"
              className="w-full sm:w-auto bg-[#D4AF37] text-black hover:bg-[#b89b31]"
            >
              <Copy className="mr-2 h-4 w-4" />
              Copy
            </Button>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-foreground/70 font-semibold">Share via:</span>
            <div className="flex space-x-2">
              <Button variant="outline" size="icon" onClick={shareOnTwitter} aria-label="Share on Twitter">
                <Twitter className="h-5 w-5 text-[#1DA1F2]" />
              </Button>
              <Button variant="outline" size="icon" onClick={shareOnInstagram} aria-label="Share on Instagram">
                <Instagram className="h-5 w-5 text-[#E4405F]" />
              </Button>
              <Button variant="outline" size="icon" onClick={copyToClipboard} aria-label="Share link">
                <Share2 className="h-5 w-5 text-foreground/80" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default Referrals;
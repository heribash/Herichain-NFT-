import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Tag, Gift, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const ListingModal = ({ isOpen, onClose, nft, onNftListed }) => {
  const [listingType, setListingType] = useState('sale');
  const [price, setPrice] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleListForSale = () => {
    setIsLoading(true);
    
    // In a real app, this would involve a smart contract interaction.
    // For now, we'll simulate it by updating local state.
    setTimeout(() => {
      const newListing = {
        id: `listing-${nft.id}`,
        nft: nft,
        price: parseFloat(price),
        seller: nft.owner,
        listedAt: new Date().toISOString(),
      };
      
      onNftListed(newListing);
      
      toast({
        title: "Heirloom Listed!",
        description: `"${nft.title}" is now on the marketplace for ${price} MATIC.`,
      });
      
      setIsLoading(false);
      onClose();
    }, 1000);
  };

  const handleGift = () => {
    setIsLoading(true);
    toast({ title: "🚧 Gifting feature is not fully implemented yet!", description: "Gifting functionality is coming soon. You can request this in your next prompt! 🚀" });
    setTimeout(() => {
      setIsLoading(false);
      onClose();
    }, 1500);
  };

  if (!isOpen) return null;

  const resolveIpfsUri = (uri) => {
    if (!uri) return null;
    if (uri.startsWith('ipfs://')) {
      return `https://ipfs.io/ipfs/${uri.substring(7)}`;
    }
    return uri;
  };
  const displayImage = resolveIpfsUri(nft.image || nft.thumbnail);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ type: "spring", duration: 0.5 }}
          className="relative bg-background border border-border rounded-2xl shadow-2xl w-full max-w-lg p-8 text-foreground"
        >
          <button onClick={onClose} className="absolute top-4 right-4 p-2 hover:bg-card rounded-full transition-colors"><X className="h-5 w-5 text-foreground/70" /></button>

          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-primary">List Your Heirloom</h2>
            <p className="text-foreground/70 mt-2">Share "{nft.title}" with the world.</p>
          </div>

          <div className="flex items-center space-x-4 mb-6">
            {displayImage && <img src={displayImage} alt={nft.title} className="w-24 h-24 object-cover rounded-lg" />}
            <div className="flex-grow">
              <h3 className="font-semibold text-lg">{nft.title}</h3>
              <p className="text-sm text-foreground/60 line-clamp-2">{nft.description}</p>
              <p className="text-xs text-foreground/50 mt-1">Token ID: {nft.tokenId}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-6 bg-card p-1 rounded-lg">
            <button onClick={() => setListingType('sale')} className={`px-4 py-2 rounded-md text-sm font-semibold transition-colors ${listingType === 'sale' ? 'bg-secondary text-secondary-foreground' : 'hover:bg-background'}`}>List for Sale</button>
            <button onClick={() => setListingType('gift')} className={`px-4 py-2 rounded-md text-sm font-semibold transition-colors ${listingType === 'gift' ? 'bg-secondary text-secondary-foreground' : 'hover:bg-background'}`}>Gift Heirloom</button>
          </div>

          {listingType === 'sale' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground/80 mb-2">Set Price (MATIC)</label>
                <div className="relative">
                  <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-foreground/40" />
                  <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} className="w-full pl-10 pr-4 py-3 bg-card border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-foreground" placeholder="e.g., 10.5" />
                </div>
              </div>
              <div className="bg-primary/10 border border-primary/20 rounded-lg p-3 text-sm text-foreground/80 flex items-start space-x-2">
                <Info className="h-4 w-4 mt-0.5 flex-shrink-0 text-primary" />
                <p>A 1% platform fee will be deducted upon sale. AI moderation will review the content before public listing.</p>
              </div>
              <Button onClick={handleListForSale} disabled={isLoading || !price || parseFloat(price) <= 0} className="w-full bg-secondary hover:bg-taupe-hover text-secondary-foreground py-3 text-lg font-semibold">
                {isLoading ? 'Listing...' : 'List for Sale'}
              </Button>
            </motion.div>
          )}

          {listingType === 'gift' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground/80 mb-2">Recipient's Wallet Address</label>
                <div className="relative">
                  <Gift className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-foreground/40" />
                  <input type="text" className="w-full pl-10 pr-4 py-3 bg-card border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-foreground" placeholder="0x..." />
                </div>
              </div>
              <div className="bg-primary/10 border border-primary/20 rounded-lg p-3 text-sm text-foreground/80 flex items-start space-x-2">
                <Info className="h-4 w-4 mt-0.5 flex-shrink-0 text-primary" />
                <p>Gifting is a direct transfer on the blockchain. This action is irreversible. Ensure the address is correct.</p>
              </div>
              <Button onClick={handleGift} disabled={isLoading} className="w-full bg-secondary hover:bg-taupe-hover text-secondary-foreground py-3 text-lg font-semibold">
                {isLoading ? 'Gifting...' : 'Gift Heirloom'}
              </Button>
            </motion.div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ListingModal;
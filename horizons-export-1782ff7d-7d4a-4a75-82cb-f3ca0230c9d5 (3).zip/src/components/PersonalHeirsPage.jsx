import React, { useRef } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { DollarSign, Gift, Zap, Award } from 'lucide-react';

const PersonalHeirsPage = () => {
  const formRef = useRef(null);

  const scrollToForm = () => {
    formRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleFormSubmit = (e) => {
    e.preventDefault();
    toast({
      title: '✅ Application Submitted!',
      description: 'Thank you for your interest! We will review your application and be in touch soon.',
    });
    e.target.reset();
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  const whyJoinItems = [
    { icon: <DollarSign className="h-8 w-8 text-primary" />, title: "90% of your NFT sales", description: "Retain the vast majority of your earnings from every NFT sale." },
    { icon: <Gift className="h-8 w-8 text-primary" />, title: "+2% lifetime from fans", description: "Earn a lifetime passive income from the platform fees of fans you refer." },
    { icon: <Zap className="h-8 w-8 text-primary" />, title: "Free minting", description: "We cover all gas fees for your mints, so you can create without cost." },
    { icon: <Award className="h-8 w-8 text-primary" />, title: "VIP badge", description: "Get global exposure, event invites, and priority support as a recognized VIP." },
  ];

  return (
    <>
      <Helmet>
        <title>Personal Heirs – VIP Program | Herichain</title>
        <meta name="description" content="Keep 90% of your sales, earn an extra 2% lifetime revenue from your referred fans' fees. Apply now for the Herichain VIP creator program." />
        <meta name="keywords" content="NFT creator program, earn from photos, digital legacy ambassador, Herichain VIP, crypto creator economy" />
      </Helmet>
      <div className="bg-white text-gray-800 font-sans">
        {/* Hero Section */}
        <motion.section 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="relative min-h-[70vh] md:min-h-screen flex items-center justify-center text-center p-4 overflow-hidden bg-gradient-to-br from-yellow-50 via-amber-100 to-yellow-50"
        >
          <div className="absolute inset-0 z-0">
            <div className="absolute -top-40 -left-40 w-96 h-96 bg-primary/10 rounded-full filter blur-3xl opacity-50 animate-pulse"></div>
            <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-pink-300/10 rounded-full filter blur-3xl opacity-50 animate-pulse animation-delay-4000"></div>
          </div>
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="relative z-10 max-w-3xl mx-auto"
          >
            <motion.h1 variants={itemVariants} className="text-4xl md:text-6xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-yellow-600 via-amber-500 to-yellow-600 mb-4 font-lora">
              Selected Creators Only
            </motion.h1>
            <motion.p variants={itemVariants} className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto mb-8">
              Keep 90% of sales + 2% lifetime from referrals.
            </motion.p>
            <motion.div variants={itemVariants}>
              <Button onClick={scrollToForm} size="lg" className="bg-[#D4AF37] text-black hover:bg-[#c8a230] text-lg px-8 py-6 rounded-full shadow-lg transition-transform transform hover:scale-105">
                Apply Now
              </Button>
            </motion.div>
          </motion.div>
        </motion.section>

        {/* Why Join Section */}
        <section className="py-16 md:py-24 bg-white">
          <div className="container mx-auto px-4">
            <motion.div 
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
            >
              {whyJoinItems.map((item, index) => (
                <motion.div key={index} variants={itemVariants} className="bg-gray-50/50 p-8 rounded-2xl text-center shadow-sm hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                  <div className="flex items-center justify-center h-16 w-16 rounded-full bg-primary/10 mx-auto mb-4">{item.icon}</div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Application Form */}
        <section ref={formRef} className="py-16 md:py-24 bg-gray-50/70">
          <div className="container mx-auto px-4 max-w-2xl">
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 font-lora">Apply for VIP Access</h2>
              <p className="text-center text-gray-600 mb-8">Fill out the form below. Spots are limited and by selection only.</p>
              <form onSubmit={handleFormSubmit} className="space-y-6 bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
                <div>
                  <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                  <Input id="fullName" type="text" placeholder="Your Name" required className="bg-gray-50 border-gray-300"/>
                </div>
                <div>
                  <label htmlFor="xHandle" className="block text-sm font-medium text-gray-700 mb-1">X Handle</label>
                  <Input id="xHandle" type="text" placeholder="@yourhandle" required className="bg-gray-50 border-gray-300"/>
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <Input id="email" type="email" placeholder="you@example.com" required className="bg-gray-50 border-gray-300"/>
                </div>
                <div>
                  <label htmlFor="why" className="block text-sm font-medium text-gray-700 mb-1">Why select you?</label>
                  <Textarea id="why" placeholder="Tell us about your community and vision..." required className="bg-gray-50 border-gray-300"/>
                </div>
                <Button type="submit" size="lg" className="w-full bg-[#D4AF37] text-black hover:bg-[#c8a230] text-lg py-4 rounded-lg">Submit</Button>
              </form>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-white py-12">
          <div className="container mx-auto px-4 text-center">
            <div className="flex flex-col sm:flex-row justify-center items-center gap-4 mb-6">
              <Button asChild variant="outline" size="lg" className="border-primary text-primary hover:bg-primary/10 hover:text-primary">
                <Link to="/marketplace">Start Minting →</Link>
              </Button>
              <Button asChild variant="ghost" size="lg">
                <Link to="/">Back to Home →</Link>
              </Button>
            </div>
            <p className="text-sm text-gray-500">Limited spots. Selected applicants only.</p>
          </div>
        </footer>
      </div>
    </>
  );
};

export default PersonalHeirsPage;
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Eye, Send, Trash2, Download, Calendar, Hash, FileText, Video, Store, BadgeCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import ListingModal from '@/components/ListingModal';

const resolveIpfsUri = (uri) => {
  if (!uri) return null;
  const gateway = 'https://ipfs.io/ipfs/';
  if (uri.startsWith('ipfs://')) {
    return `${gateway}${uri.substring(7)}`;
  }
  const cidMatch = uri.match(/^(Qm[1-9A-HJ-NP-Za-km-z]{44,}|b[A-Za-z2-7]{58,}|B[A-Z2-7]{58,}|z[1-9A-HJ-NP-Za-km-z]{48,}|F[0-9A-F]{50,})$/);
  if (cidMatch) {
    return `${gateway}${cidMatch[0]}`;
  }
  return uri;
};

const NFTCard = ({ nft, index, onTransfer, onDelete, onDownload, onList }) => {
  const metadata = nft.metadata || {};
  const isVideo = metadata.animation_url || (metadata.fileType && metadata.fileType.startsWith('video/'));
  const displayImage = resolveIpfsUri(metadata.image || metadata.thumbnail);
  const videoSrc = resolveIpfsUri(metadata.animation_url);

  const getMintedAt = () => {
    const mintedAtAttr = metadata.attributes?.find(attr => attr.trait_type === "Minted At");
    return new Date(mintedAtAttr?.value || Date.now()).toLocaleDateString();
  };

  return (
    <motion.div
      key={nft.id.toString()}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="nft-card-nostalgic rounded-xl shadow-lg flex flex-col"
    >
      <div className="aspect-w-1 aspect-h-1 w-full bg-background relative">
        {isVideo && videoSrc ? (
          <video
            src={videoSrc}
            poster={displayImage}
            controls
            className="w-full h-full object-cover rounded-t-xl"
          >
            Your browser does not support the video tag.
          </video>
        ) : displayImage ? (
          <img src={displayImage} alt={metadata.name} className="w-full h-full object-cover rounded-t-xl" />
        ) : (
          <div className="flex items-center justify-center text-center p-4 text-primary rounded-t-xl">
            {isVideo ? <Video className="h-16 w-16" /> : <FileText className="h-16 w-16" />}
          </div>
        )}
        {!isVideo && <div className="page-turn-effect"></div>}
        {nft.isListed && (
          <div className="absolute top-2 right-2 bg-primary text-primary-foreground px-2 py-1 text-xs font-bold rounded-full flex items-center">
            <BadgeCheck className="h-3 w-3 mr-1" />
            Listed
          </div>
        )}
      </div>
      
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="font-bold text-lg text-foreground mb-1 truncate">{metadata.name || 'Untitled Heirloom'}</h3>
        <p className="text-sm text-foreground/70 mb-3 line-clamp-2 flex-grow">{metadata.description || 'No description provided'}</p>
        <div className="text-xs text-foreground/50 flex items-center justify-between mt-2">
          <div className="flex items-center space-x-1"><Calendar className="h-3 w-3" /><span>{getMintedAt()}</span></div>
          <div className="flex items-center space-x-1"><Hash className="h-3 w-3" /><span>{nft.id.toString()}</span></div>
        </div>
        <div className="border-t border-border my-3"></div>
        <div className="flex justify-around items-center">
          <Button size="sm" variant="ghost" onClick={() => onList(nft)} disabled={nft.isListed}><Store className={`h-5 w-5 ${nft.isListed ? 'text-foreground/40' : 'text-foreground/70 hover:text-primary'}`} /></Button>
          <Button size="sm" variant="ghost" onClick={() => onTransfer(nft)}><Send className="h-5 w-5 text-foreground/70 hover:text-primary" /></Button>
          <Button size="sm" variant="ghost" onClick={() => onDownload(nft)}><Download className="h-5 w-5 text-foreground/70 hover:text-primary" /></Button>
          <Button size="sm" variant="ghost" onClick={() => onDelete(nft.id)}><Trash2 className="h-5 w-5 text-red-500 hover:text-red-400" /></Button>
        </div>
      </div>
    </motion.div>
  );
};

const NFTGallery = ({ nfts, setNfts, onNftListed }) => {
  const [selectedNft, setSelectedNft] = useState(null);
  const [isListingModalOpen, setIsListingModalOpen] = useState(false);
  
  const handleListNft = (nft) => {
    const metadata = nft.metadata || {};
    const nftToFormat = {
      id: nft.id.toString(),
      tokenId: nft.id.toString(),
      title: metadata.name,
      description: metadata.description,
      image: metadata.image,
      mintedAt: metadata.attributes?.find(attr => attr.trait_type === "Minted At")?.value,
    };

    if (nft.isListed) {
      toast({ title: "Already Listed", description: "This heirloom is already on the marketplace." });
      return;
    }
    setSelectedNft(nftToFormat);
    setIsListingModalOpen(true);
  };

  const handleTransferNft = (nft) => toast({ title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" });
  
  const handleDeleteNft = (nftId) => {
    setNfts(currentNfts => currentNfts.filter(nft => nft.id !== nftId));
    toast({ title: "Heirloom Hidden", description: "Your memory has been removed from this view. It is still on the blockchain." });
  };

  const handleDownload = (nft) => {
    const metadata = nft.metadata || {};
    const downloadUrl = resolveIpfsUri(metadata.animation_url || metadata.image);
    if (downloadUrl) {
      window.open(downloadUrl, '_blank');
    } else {
      toast({ title: "Download Failed", description: "No IPFS link found for this heirloom.", variant: "destructive" });
    }
  };

  if (nfts.length === 0) {
    return (
      <div className="text-center py-12 px-6">
        <div className="w-24 h-24 bg-background rounded-full flex items-center justify-center mx-auto mb-6"><Eye className="h-12 w-12 text-foreground/40" /></div>
        <h3 className="text-xl font-semibold text-foreground mb-2">No Heirlooms Yet</h3>
        <p className="text-foreground/70 mb-6">Begin your legacy by archiving your first heirloom.</p>
      </div>
    );
  }

  return (
    <>
      <div className="p-6">
        <div 
          className="grid gap-8"
          style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))' }}
        >
          {nfts.map((nft, index) => (
            <NFTCard key={nft.id.toString()} nft={nft} index={index} onList={handleListNft} onTransfer={handleTransferNft} onDelete={handleDeleteNft} onDownload={handleDownload} />
          ))}
        </div>
      </div>
      {selectedNft && (
        <ListingModal
          isOpen={isListingModalOpen}
          onClose={() => setIsListingModalOpen(false)}
          nft={selectedNft}
          onNftListed={onNftListed}
        />
      )}
    </>
  );
};

export default NFTGallery;
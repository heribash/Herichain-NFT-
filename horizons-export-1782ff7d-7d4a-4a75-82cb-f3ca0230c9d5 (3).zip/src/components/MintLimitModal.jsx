import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { X, Zap, Gem } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const MintLimitModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handlePayment = (method) => {
    toast({
      title: '🚧 Feature in Development',
      description: `The ${method} payment option is not yet implemented. Please check back soon! 🚀`,
    });
    onClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 30 }}
        animate={{ scale: 1, y: 0 }}
        transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.1 }}
        className="relative max-w-lg w-full bg-gradient-to-br from-card via-background to-card rounded-2xl shadow-2xl overflow-hidden border border-border"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-foreground/70 hover:text-foreground transition-colors z-10"
          aria-label="Close"
        >
          <X size={24} />
        </button>
        
        <div className="p-8 text-center">
          <div className="mx-auto mb-6 w-20 h-20 rounded-full bg-gradient-to-br from-pink-400 to-[#D4AF37] flex items-center justify-center">
             <Zap className="h-12 w-12 text-white" />
          </div>

          <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#D4AF37] to-pink-500 mb-4">
            Unlock More Mints!
          </h2>
          <p className="text-foreground/80 mb-6">
            You've used all your free mints. Keep your legacy growing by purchasing more.
          </p>

          <div className="bg-background/50 border border-border rounded-lg p-6 space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-3">
                <Gem className="h-6 w-6 text-primary" />
                <span className="text-xl font-semibold text-foreground">20 Mints</span>
              </div>
              <span className="text-2xl font-bold text-foreground">$5</span>
            </div>
            <p className="text-sm text-foreground/70 text-left">
              Get 20 more sponsored (gas-free) mints to archive your precious memories.
            </p>
          </div>

          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Button
              onClick={() => handlePayment('Stripe')}
              size="lg"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-6 text-base"
            >
              Pay with Stripe
            </Button>
            <Button
              onClick={() => handlePayment('USDT')}
              size="lg"
              className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-6 text-base"
            >
              Pay with USDT
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default MintLimitModal;
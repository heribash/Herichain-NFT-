import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail, KeyRound, User, Wallet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { useConnect } from 'thirdweb/react';
import { inAppWallet, preAuthenticate, createWallet, walletConnect } from 'thirdweb/wallets';
import { client } from '@/main';

const AuthModal = ({ isOpen, onClose, mode, onLogin, onSwitchMode }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    verificationCode: '',
    agreeToTerms: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isWalletConnecting, setIsWalletConnecting] = useState(false);
  const [verificationSent, setVerificationSent] = useState(false);
  const { connect } = useConnect();

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handlePreAuth = async () => {
    if (!formData.email) {
      toast({ title: "Email is required", description: "Please enter your email address.", variant: "destructive" });
      return;
    }
    if (mode === 'signup' && !formData.agreeToTerms) {
      toast({ title: "Terms not accepted", description: "You must agree to the terms to sign up.", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    try {
      await preAuthenticate({
        client,
        strategy: "email",
        email: formData.email,
      });
      setVerificationSent(true);
      toast({ title: "Verification Code Sent", description: "Check your email for the code." });
    } catch (error) {
      console.error("Pre-authentication failed", error);
      toast({ title: "Authentication Failed", description: "Could not send verification code. Please try again.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailConnect = async () => {
    if (!formData.verificationCode) {
      toast({ title: "Verification code is required", description: "Please enter the code from your email.", variant: "destructive" });
      return;
    }
    setIsLoading(true);
    try {
      const wallet = await connect(async () => {
        const inApp = inAppWallet();
        await inApp.connect({
          client,
          strategy: "email",
          email: formData.email,
          verificationCode: formData.verificationCode,
        });
        return inApp;
      });

      const userData = {
        id: wallet.getAccount().address,
        name: formData.name || formData.email.split('@')[0],
        email: formData.email,
        walletAddress: wallet.getAccount().address,
        joinDate: new Date().toISOString()
      };
      onLogin(userData);
      toast({ title: mode === 'signup' ? "Welcome to Herichain!" : "Welcome back!", description: "You have successfully logged in." });
      resetForm();
    } catch (error) {
      console.error("Connection failed", error);
      toast({ title: "Login Failed", description: "Invalid verification code or an error occurred.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleWalletConnect = async (walletFactory) => {
    setIsWalletConnecting(true);
    try {
      const wallet = await connect(async () => {
        const configuredWallet = walletFactory();
        await configuredWallet.connect({ client });
        return configuredWallet;
      });
      
      const account = wallet.getAccount();
      if (account) {
        const userData = {
          id: account.address,
          name: account.address.slice(0, 6),
          email: `wallet-user-${account.address.slice(0, 6)}@herichain.io`,
          walletAddress: account.address,
          joinDate: new Date().toISOString()
        };
        onLogin(userData);
        toast({ title: "Vault Connected!", description: "You have successfully logged in with your wallet." });
        resetForm();
      }
    } catch (error) {
      console.error("Wallet connection failed", error);
      toast({ title: "Connection Failed", description: "Could not connect to the wallet. Please try again.", variant: "destructive" });
    } finally {
      setIsWalletConnecting(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (verificationSent) {
      handleEmailConnect();
    } else {
      handlePreAuth();
    }
  };

  const resetForm = () => {
    setFormData({ name: '', email: '', verificationCode: '', agreeToTerms: false });
    setVerificationSent(false);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleSwitch = (newMode) => {
    resetForm();
    onSwitchMode(newMode);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50 backdrop-blur-sm" onClick={handleClose} />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ type: "spring", duration: 0.5 }}
          className="relative bg-background border border-border rounded-2xl shadow-2xl w-full max-w-md p-8 text-foreground"
        >
          <button onClick={handleClose} className="absolute top-4 right-4 p-2 hover:bg-card rounded-full transition-colors"><X className="h-5 w-5 text-foreground/70" /></button>

          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-primary">{mode === 'signup' ? 'Join Herichain' : 'Welcome Back'}</h2>
            <p className="text-foreground/70 mt-2">{mode === 'signup' ? 'Begin your gentle legacy' : 'Continue your heritage journey'}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <AnimatePresence mode="wait">
              {!verificationSent ? (
                <motion.div
                  key="email-step"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  {mode === 'signup' && (
                    <div>
                      <label className="block text-sm font-medium text-foreground/80 mb-2">Full Name</label>
                      <div className="relative"><User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-foreground/40" /><input type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full pl-10 pr-4 py-3 bg-card border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-foreground" placeholder="Enter your full name" /></div>
                    </div>
                  )}
                  <div>
                    <label className="block text-sm font-medium text-foreground/80 mb-2">Email Address</label>
                    <div className="relative"><Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-foreground/40" /><input type="email" name="email" value={formData.email} onChange={handleInputChange} className="w-full pl-10 pr-4 py-3 bg-card border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-foreground" placeholder="Enter your email" required /></div>
                  </div>
                  {mode === 'signup' && (
                    <div className="flex items-start space-x-3">
                      <input id="agreeToTerms" type="checkbox" name="agreeToTerms" checked={formData.agreeToTerms} onChange={handleInputChange} className="mt-1 h-4 w-4 text-primary bg-card border-border focus:ring-primary" required />
                      <label htmlFor="agreeToTerms" className="text-sm text-foreground/70">By signing up, you agree to use Herichain with full consent. Your heritage is encrypted and stored safely.</label>
                    </div>
                  )}
                </motion.div>
              ) : (
                <motion.div
                  key="code-step"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div>
                    <label className="block text-sm font-medium text-foreground/80 mb-2">Verification Code</label>
                    <div className="relative"><KeyRound className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-foreground/40" /><input type="text" name="verificationCode" value={formData.verificationCode} onChange={handleInputChange} className="w-full pl-10 pr-4 py-3 bg-card border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-foreground" placeholder="Enter code from email" required /></div>
                    <button type="button" onClick={() => setVerificationSent(false)} className="text-sm text-primary hover:underline mt-2">Use a different email</button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <Button type="submit" disabled={isLoading} className="w-full bg-secondary hover:bg-taupe-hover text-secondary-foreground py-3 text-lg font-semibold">
              {isLoading ? <div className="flex items-center justify-center space-x-2"><div className="w-5 h-5 border-2 border-secondary-foreground border-t-transparent rounded-full animate-spin"></div><span>{verificationSent ? 'Verifying...' : 'Sending Code...'}</span></div> : (verificationSent ? 'Verify & Connect' : 'Continue with Email')}
            </Button>
          </form>

          <div className="relative flex py-5 items-center">
            <div className="flex-grow border-t border-border"></div>
            <span className="flex-shrink mx-4 text-foreground/50">OR</span>
            <div className="flex-grow border-t border-border"></div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="w-full" onClick={() => handleWalletConnect(() => createWallet('io.metamask'))} disabled={isWalletConnecting}>
              MetaMask
            </Button>
            <Button variant="outline" className="w-full" onClick={() => handleWalletConnect(() => createWallet('com.coinbase.wallet'))} disabled={isWalletConnecting}>
              Coinbase
            </Button>
            <Button variant="outline" className="w-full" onClick={() => handleWalletConnect(() => createWallet('com.trustwallet.app'))} disabled={isWalletConnecting}>
              Trust Wallet
            </Button>
            <Button variant="outline" className="w-full" onClick={() => handleWalletConnect(() => createWallet('me.rainbow'))} disabled={isWalletConnecting}>
              Rainbow
            </Button>
            <Button variant="outline" className="w-full" onClick={() => handleWalletConnect(() => createWallet('app.phantom'))} disabled={isWalletConnecting}>
              Phantom
            </Button>
            <Button variant="outline" className="w-full" onClick={() => handleWalletConnect(walletConnect)} disabled={isWalletConnecting}>
              WalletConnect
            </Button>
          </div>

          <div className="mt-6 text-center">
            <p className="text-foreground/70">{mode === 'signup' ? 'Already have an account?' : "Don't have an account?"}<button onClick={() => handleSwitch(mode === 'signup' ? 'login' : 'signup')} className="ml-2 text-primary hover:underline font-semibold">{mode === 'signup' ? 'Sign In' : 'Sign Up'}</button></p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default AuthModal;
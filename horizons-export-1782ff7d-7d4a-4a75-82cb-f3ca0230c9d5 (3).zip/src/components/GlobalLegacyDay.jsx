import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Globe, Info, Calendar, Gift, Share2, BarChart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const GlobalLegacyDay = () => {
  const [sharedCount, setSharedCount] = useState(42);

  const handleShare = () => {
    setSharedCount(sharedCount + 1);
    toast({ title: "Shared for #GlobalLegacyDay!", description: "Thank you for being part of the movement." });
  };

  const leaderboard = [
    { name: "Grandma's Recipe Book", shares: 152, user: "Alex" },
    { name: "1988 Family Vacation Video", shares: 121, user: "Maria" },
    { name: "Dad's War Letters", shares: 98, user: "Chen" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="p-8"
    >
      <div className="flex items-center mb-6">
        <Globe className="h-8 w-8 text-primary mr-4" />
        <h2 className="text-3xl font-bold text-foreground">Global Legacy Day</h2>
      </div>
      
      <Card className="mb-8 bg-background/70">
        <CardHeader>
          <div className="flex items-start">
            <Info className="h-5 w-5 text-primary mr-3 mt-1 flex-shrink-0" />
            <div>
              <CardTitle className="text-primary">Join the Celebration on December 1st!</CardTitle>
              <p className="text-sm text-foreground/80 mt-1">
                Mint and share your heirlooms with the world using #GlobalLegacyDay. Let's create a global tapestry of memories.
              </p>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="bg-background/70 flex flex-col items-center justify-center text-center">
          <CardHeader>
            <div className="w-24 h-24 bg-card rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="h-12 w-12 text-foreground/40" />
            </div>
            <CardTitle>Share Your Legacy</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-foreground/70 mb-6">
              Click the button to mint a new heirloom or share an existing one to the public #GlobalLegacyDay feed.
            </p>
            <Button onClick={handleShare}>
              <Share2 className="mr-2 h-4 w-4" />
              Share for #GlobalLegacyDay
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-background/70">
          <CardHeader>
            <div className="flex items-center">
              <BarChart className="h-6 w-6 mr-3 text-primary" />
              <CardTitle>Live Leaderboard</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              {leaderboard.map((item, index) => (
                <li key={index} className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{item.name}</p>
                    <p className="text-xs text-foreground/60">by {item.user}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-primary">{item.shares}</p>
                    <p className="text-xs text-foreground/60">shares</p>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
};

export default GlobalLegacyDay;
import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Upload, Gem, Wallet, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const LandingPage = ({ onGetStarted }) => {
  const features = [
    {
      icon: Upload,
      title: "Gentle Upload",
      description: "Simply drag & drop your precious memories - photos, documents, or voice notes."
    },
    {
      icon: Shield,
      title: "Eternal Security",
      description: "Your memories are encrypted and stored forever on IPFS with blockchain verification."
    },
    {
      icon: Gem,
      title: "NFT Minting",
      description: "Transform memories into unique digital heirlooms on the Polygon blockchain."
    },
    {
      icon: Wallet,
      title: "Personal Vault",
      description: "Manage, view, and transfer your digital heritage with warmth and simplicity."
    }
  ];

  return (
    <div className="h-screen bg-background text-foreground flex flex-col items-center justify-between p-4 overflow-hidden">
      {/* Hero Section - Centered and takes most of the space */}
      <section className="flex-1 flex items-center justify-center text-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-4xl md:text-6xl font-bold text-primary mb-4 leading-tight">
            <span className="font-lora text-primary">Herichain:</span> A Gentle Transfer of Legacy
          </h1>
          <p className="text-lg md:text-xl text-foreground/80 mb-8">
            Transform precious family memories into secure, timeless digital assets, like pages in a cherished album.
          </p>
          <div className="flex flex-col items-center space-y-4">
            <Button
              size="lg"
              onClick={onGetStarted} // This will trigger the authentication flow
              className="bg-[#D4AF37] hover:bg-[#b89b31] text-black font-bold text-lg px-10 py-5 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105 w-full max-w-sm"
            >
              Continue to Herichain
              <ArrowRight className="ml-3 h-6 w-6" />
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline" // Using outline to differentiate slightly but keeping the gold theme
              className="border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10 hover:text-[#D4AF37] font-bold text-lg px-10 py-5 rounded-full transition-all duration-300 transform hover:scale-105 w-full max-w-sm"
            >
              <Link to="/heirs">
                Become a Personal Heir →
              </Link>
            </Button>
          </div>
        </motion.div>
      </section>

      {/* Features Section - Reduced for single screen view */}
      <section className="w-full max-w-7xl px-4 py-4 md:py-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="text-center p-2 rounded-xl bg-card/50 flex flex-col items-center justify-center"
            >
              <div className="w-10 h-10 md:w-12 md:h-12 bg-secondary rounded-full flex items-center justify-center mx-auto mb-2">
                <feature.icon className="h-5 w-5 md:h-6 md:w-6 text-secondary-foreground" />
              </div>
              <h3 className="text-md md:text-lg font-semibold text-foreground mb-1">
                {feature.title}
              </h3>
              <p className="text-xs md:text-sm text-foreground/70 leading-tight">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
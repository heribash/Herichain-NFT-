import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Info, Award, Star, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const MemoryChallenges = ({ nfts }) => {
  const [submissions, setSubmissions] = useState([]);
  const [showLeaderboard, setShowLeaderboard] = useState(true);

  const handleSubmit = (nft) => {
    if (submissions.some(sub => sub.id === nft.id)) {
      toast({ title: "Already Submitted", description: "You've already submitted this heirloom for the challenge." });
      return;
    }
    const newSubmission = { ...nft, votes: 0 };
    setSubmissions([...submissions, newSubmission]);
    toast({ title: "Heirloom Submitted!", description: `"${nft.title}" is now in the running.` });
  };

  const handleVote = (nftId) => {
    setSubmissions(submissions.map(sub => 
      sub.id === nftId ? { ...sub, votes: sub.votes + 1 } : sub
    ).sort((a, b) => b.votes - a.votes));
    toast({ title: "Vote Cast!", description: "Thank you for participating in the community vote." });
  };

  const leaderboard = submissions.slice(0, 3);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="p-8"
    >
      <div className="flex items-center mb-6">
        <Trophy className="h-8 w-8 text-primary mr-4" />
        <h2 className="text-3xl font-bold text-foreground">Memory Challenges</h2>
      </div>
      
      <Card className="mb-8 bg-background/70">
        <CardHeader>
          <div className="flex items-start">
            <Info className="h-5 w-5 text-primary mr-3 mt-1 flex-shrink-0" />
            <div>
              <CardTitle className="text-primary">Weekly Challenge: Best Childhood Memory</CardTitle>
              <p className="text-sm text-foreground/80 mt-1">
                Submit a minted heirloom that represents a cherished childhood memory. The community votes for the winner!
              </p>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Card className="bg-background/70">
            <CardHeader>
              <CardTitle>Challenge Submissions</CardTitle>
            </CardHeader>
            <CardContent>
              {submissions.length > 0 ? (
                <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                  {submissions.map(nft => (
                    <div key={nft.id} className="flex items-center justify-between bg-card p-3 rounded-lg">
                      <div>
                        <p className="font-semibold">{nft.title}</p>
                        <p className="text-sm text-foreground/60">{nft.votes} votes</p>
                      </div>
                      <Button size="sm" onClick={() => handleVote(nft.id)}>
                        <Star className="h-4 w-4 mr-2" /> Vote
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-foreground/70 text-center py-8">No submissions yet. Be the first!</p>
              )}
            </CardContent>
          </Card>
        </div>
        <div>
          <Card className="bg-background/70">
            <CardHeader className="cursor-pointer" onClick={() => setShowLeaderboard(!showLeaderboard)}>
              <div className="flex justify-between items-center">
                <CardTitle>Leaderboard</CardTitle>
                {showLeaderboard ? <ChevronUp /> : <ChevronDown />}
              </div>
            </CardHeader>
            {showLeaderboard && (
              <CardContent>
                {leaderboard.length > 0 ? (
                  <ul className="space-y-3">
                    {leaderboard.map((nft, index) => (
                      <li key={nft.id} className="flex items-center">
                        <Award className={`h-6 w-6 mr-3 ${index === 0 ? 'text-yellow-400' : index === 1 ? 'text-gray-400' : 'text-yellow-600'}`} />
                        <div className="flex-grow">
                          <p className="font-medium truncate">{nft.title}</p>
                          <p className="text-xs text-foreground/60">{nft.votes} votes</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-foreground/70 text-center py-4">Vote for your favorite submission!</p>
                )}
              </CardContent>
            )}
          </Card>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button className="w-full mt-4">Submit an Heirloom</Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Select an Heirloom to Submit</AlertDialogTitle>
                <AlertDialogDescription>
                  Choose one of your archived heirlooms to enter into the "Best Childhood Memory" challenge.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="max-h-60 overflow-y-auto my-4 space-y-2 pr-2">
                {nfts.length > 0 ? nfts.map(nft => (
                  <div key={nft.id} className="flex justify-between items-center p-2 rounded-md hover:bg-accent">
                    <span>{nft.title}</span>
                    <Button size="sm" variant="secondary" onClick={() => handleSubmit(nft)}>Select</Button>
                  </div>
                )) : <p className="text-center text-foreground/70">You have no heirlooms to submit.</p>}
              </div>
              <AlertDialogFooter>
                <AlertDialogCancel>Close</AlertDialogCancel>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </motion.div>
  );
};

export default MemoryChallenges;
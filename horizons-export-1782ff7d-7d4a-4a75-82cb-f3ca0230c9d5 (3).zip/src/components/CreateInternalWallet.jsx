import React from 'react';
import { motion } from 'framer-motion';
import { Wallet, Mail } from 'lucide-react';
import { ConnectButton } from 'thirdweb/react';
import { inAppWallet, createWallet, walletConnect } from 'thirdweb/wallets';
import { client } from '@/main';
import { polygonAmoy } from 'thirdweb/chains';

const CreateInternalWallet = ({ user }) => {
  if (!user || !user.email) {
    return (
      <div className="flex flex-col items-center justify-center text-center h-full p-8">
        <p className="text-foreground/70">Please log in to create or connect a secure vault.</p>
      </div>
    );
  }

  const wallets = [
    inAppWallet({
      auth: {
        options: ["email"],
      },
    }),
    createWallet('io.metamask'),
    createWallet('com.coinbase.wallet'),
    walletConnect(),
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center text-center h-full p-8"
    >
      <div className="w-24 h-24 bg-background rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-dashed border-primary">
        <Wallet className="h-12 w-12 text-primary/80" />
      </div>
      <h2 className="text-2xl font-bold text-foreground mb-2">Connect Your Secure Vault</h2>
      <p className="text-foreground/70 mb-6 max-w-md">
        To archive your heirlooms on the Polygon Amoy Testnet, you need a vault. Create one with your email or connect an existing wallet.
      </p>

      <div className="w-full max-w-sm space-y-4">
        <ConnectButton
          client={client}
          wallets={wallets}
          chain={polygonAmoy}
          connectButton={{
            label: "Connect Vault",
            style: {
              width: '100%',
              backgroundColor: 'hsl(var(--secondary))',
              color: 'hsl(var(--secondary-foreground))',
              fontWeight: '600',
              fontSize: '1.125rem',
              paddingTop: '0.75rem',
              paddingBottom: '0.75rem',
            }
          }}
          connectModal={{
            size: "compact",
            title: "Connect Your Vault",
            showThirdwebBranding: false,
            networkSelector: {
              title: "Network",
              supportedNetworks: [polygonAmoy],
            },
            welcomeScreen: {
              title: "Your Digital Legacy Vault",
              subtitle: "Connect to archive on the Polygon Amoy Testnet."
            }
          }}
          connectOptions={{
            strategy: "email",
            email: user.email,
          }}
        />

        <p className="text-sm text-foreground/60">
          A popup will appear to guide you through the connection process.
        </p>
      </div>
    </motion.div>
  );
};

export default CreateInternalWallet;
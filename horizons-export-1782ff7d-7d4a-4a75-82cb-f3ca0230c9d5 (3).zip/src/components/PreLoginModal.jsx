import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { X, ShieldCheck, Gem, BarChart, ArrowRight } from 'lucide-react';

const PreLoginModal = ({ onClose, onGetStarted }) => {
  const images = [
    'https://images.unsplash.com/photo-1543269865-cbf427effbad?q=80&w=2070', // Family image
    'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1945', // Selfie image
    'https://images.unsplash.com/photo-1558507652-2d9626c4e67a?q=80&w=1935', // Art image
  ];

  const benefits = [
    {
      icon: <ShieldCheck className="h-6 w-6 text-secondary-foreground" />,
      title: 'For Families',
      text: 'Preserve your family’s legacy. Store precious memories in a secure, private digital vault that lasts for generations.',
    },
    {
      icon: <Gem className="h-6 w-6 text-secondary-foreground" />,
      title: 'For Youth',
      text: 'Monetize your creativity. Turn your best selfies, digital art, or moments into valuable NFTs and earn from your talent.',
    },
    {
      icon: <BarChart className="h-6 w-6 text-secondary-foreground" />,
      title: 'Earn Your Way',
      text: 'Benefit from a low 1% commission on sales and earn royalties every time your creation is resold.',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 30 }}
        animate={{ scale: 1, y: 0 }}
        transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.1 }}
        className="relative max-w-4xl w-full bg-gradient-to-br from-card to-background rounded-2xl shadow-2xl overflow-hidden border border-border"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-foreground/70 hover:text-foreground transition-colors z-10"
          aria-label="Close"
        >
          <X size={24} />
        </button>

        <div className="flex flex-col md:flex-row">
          {/* Left Side - Content */}
          <div className="w-full md:w-1/2 p-8 flex flex-col justify-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground leading-tight mb-4">
              Herichain: <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] to-[#F0E68C]">
                Eternal Treasures
              </span>
            </h1>

            <p className="text-foreground/80 mb-6">
              Preserve family legacies in secure vaults, or turn your youthful creativity into timeless NFT art.
            </p>

            <div className="space-y-4 mb-8">
              {benefits.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 + index * 0.2 }}
                  className="flex items-start space-x-3"
                >
                  <div className="flex-shrink-0 bg-secondary p-2 rounded-full">{item.icon}</div>
                  <div>
                    <h3 className="font-semibold text-foreground">{item.title}</h3>
                    <p className="text-foreground/70 text-sm">{item.text}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.9 }}
            >
              <Button
                onClick={onGetStarted}
                className="w-full bg-gradient-to-r from-[#D4AF37] to-[#e6c76c] text-black font-bold text-lg px-8 py-6 rounded-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
              >
                Start Free Signup
                <ArrowRight className="ml-2" />
              </Button>
            </motion.div>
          </div>

          {/* Right Side - Image Carousel */}
          <div className="w-full md:w-1/2 relative overflow-hidden hidden md:block">
            {images.map((src, index) => (
              <motion.div
                key={src}
                className="absolute inset-0 h-full w-full"
                initial={{ opacity: index === 0 ? 1 : 0 }}
                animate={{
                  opacity: 1,
                  transition: {
                    delay: index * 5,
                    duration: 1.5,
                    repeat: Infinity,
                    repeatDelay: images.length * 5 - 1.5,
                    repeatType: 'loop',
                  },
                }}
              >
                <img
                  alt={`Rotating image ${index + 1}`}
                  class="w-full h-full object-cover"
                 src={src} />
                <div className="absolute inset-0 bg-card/30"></div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default PreLoginModal;
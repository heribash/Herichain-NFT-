import React from 'react';
import { motion } from 'framer-motion';

const Logo = () => {
  return (
    <motion.div 
      className="flex items-center space-x-3"
      whileHover={{ scale: 1.05 }}
      transition={{ type: "spring", stiffness: 400, damping: 10 }}
    >
      <div className="relative">
        <svg width="40" height="40" viewBox="0 0 40 40" className="p-1">
          {/* Roots (Soft Taupe) */}
          <g stroke="#B7A99A" strokeWidth="2" fill="none" strokeLinecap="round">
            <path d="M20 38 V 30" />
            <path d="M15 38 Q 17 34, 20 30" />
            <path d="M25 38 Q 23 34, 20 30" />
          </g>
          
          {/* Album Pages / Tree (Muted Rose) */}
          <g stroke="#D8A7B1" strokeWidth="2" fill="none" strokeLinecap="round">
            <path d="M20 30 C 10 28, 5 20, 5 10" />
            <path d="M20 30 C 30 28, 35 20, 35 10" />
            <path d="M20 30 Q 15 20, 12 12" />
            <path d="M20 30 Q 25 20, 28 12" />
          </g>
        </svg>
      </div>
      
      <div>
        <span className="text-2xl font-bold text-primary font-['Cardo']">
          Herichain
        </span>
        <div className="text-xs text-foreground/70 font-medium tracking-wider">
          GENTLE LEGACY
        </div>
      </div>
    </motion.div>
  );
};

export default Logo;
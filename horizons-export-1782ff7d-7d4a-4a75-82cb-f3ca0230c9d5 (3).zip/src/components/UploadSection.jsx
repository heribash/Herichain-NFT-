import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Upload, File, Image, Mic, X, CreditCard, Video, CheckCircle, ShieldCheck, Copy, PlusCircle, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { useActiveAccount } from 'thirdweb/react';
import { getContract, sendAndConfirmTransaction } from 'thirdweb';
import { polygonAmoy } from 'thirdweb/chains';
import { upload } from 'thirdweb/storage';
import { lazyMint } from 'thirdweb/extensions/erc721';
import { client } from '@/main';
import { appConfig } from '@/config';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";
import MintLimitModal from '@/components/MintLimitModal';

const STEPS = [
  { name: "Uploading", icon: Upload },
  { name: "Minting", icon: CreditCard },
  { name: "Verifying", icon: ShieldCheck },
  { name: "Complete", icon: CheckCircle },
];

const UploadSection = ({ user, onNftMinted }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [dragActive, setDragActive] = useState(false);
  const [thumbnail, setThumbnail] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [successData, setSuccessData] = useState(null);
  const [showMintLimitModal, setShowMintLimitModal] = useState(false);
  const fileInputRef = useRef(null);

  const account = useActiveAccount();
  const hasMints = user.mintsRemaining > 0;

  useEffect(() => {
    if (selectedFile && selectedFile.type.startsWith('video/')) {
      // Video thumbnail generation... (same as before)
    } else if (selectedFile && selectedFile.type.startsWith('image/')) {
      setThumbnail(URL.createObjectURL(selectedFile));
    } else {
      setThumbnail(null);
    }
  }, [selectedFile]);

  const handleDrag = (e) => { e.preventDefault(); e.stopPropagation(); if (e.type === "dragenter" || e.type === "dragover") setDragActive(true); else if (e.type === "dragleave") setDragActive(false); };
  const handleDrop = (e) => { e.preventDefault(); e.stopPropagation(); setDragActive(false); if (e.dataTransfer.files && e.dataTransfer.files[0]) handleFileSelect(e.dataTransfer.files[0]); };
  const handleFileSelect = (file) => {
    if (!hasMints) { setShowMintLimitModal(true); return; }
    if (file.size > 10 * 1024 * 1024) { toast({ title: "File Too Large", description: "Please select a file smaller than 10MB", variant: "destructive" }); return; }
    const allowedTypes = ['image/', 'video/', 'audio/', 'text/', 'application/pdf'];
    if (!allowedTypes.some(type => file.type.startsWith(type))) { toast({ title: "Invalid File Type", description: "Please select an image, video, audio, text, or PDF file.", variant: "destructive" }); return; }
    setSelectedFile(file);
  };
  const handleFileInputChange = (e) => { if (e.target.files && e.target.files[0]) handleFileSelect(e.target.files[0]); };
  const removeFile = () => { setSelectedFile(null); setThumbnail(null); if (fileInputRef.current) fileInputRef.current.value = ''; };
  const getFileIcon = (file) => { if (file.type.startsWith('image/')) return Image; if (file.type.startsWith('audio/')) return Mic; if (file.type.startsWith('video/')) return Video; return File; };

  const confirmMint = () => {
    if (!hasMints) { setShowMintLimitModal(true); return; }
    if (!selectedFile) { toast({ title: "Missing File", description: "Please provide a file to archive.", variant: "destructive" }); return; }
    if (!account) { toast({ title: "Vault Not Connected", description: "Please connect your wallet to archive an heirloom.", variant: "destructive" }); return; }
    setShowConfirmation(true);
  };

  const handleMintNFT = async () => {
    setShowConfirmation(false);
    if (!account) { toast({ title: "Vault Not Connected", description: "Please connect your wallet to archive an heirloom.", variant: "destructive" }); return; }

    setIsProcessing(true);
    setSuccessData(null);
    try {
      setCurrentStep(0);
      toast({ title: "Uploading Heirloom...", description: "Your file is being uploaded to decentralized storage." });
      
      const fileUri = await upload({ 
        client, 
        files: [selectedFile],
      });

      setCurrentStep(1);
      toast({ title: "Ready to Mint!", description: "Preparing your sponsored heirloom token." });
      
      const contract = getContract({ client, chain: polygonAmoy, address: appConfig.nftContractAddress });
      
      const nftMetadata = {
        name: selectedFile.name,
        description: `A digital heirloom archived on ${new Date().toLocaleDateString()}`,
        image: fileUri,
      };

      // Using Lazy Mint for sponsored transactions
      const tx = lazyMint({
        contract,
        nfts: [nftMetadata],
      });
      
      // The sendAndConfirmTransaction is what would be sponsored on the backend.
      // For client-side simulation, we still need the user's account to sign.
      const { receipt } = await sendAndConfirmTransaction({
        transaction: tx,
        account: account,
      });

      const transferLog = receipt.logs.find(log => log.topics[0] === '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef');
      const tokenId = transferLog ? parseInt(transferLog.topics[3], 16).toString() : Date.now().toString(); // Fallback tokenId

      setCurrentStep(2);
      toast({ title: "Verifying Transaction...", description: "Confirming your heirloom on the blockchain." });
      
      const newNft = { 
        id: `${tokenId}-${receipt.transactionHash}`,
        title: selectedFile.name, 
        description: nftMetadata.description,
        fileName: selectedFile.name, 
        fileSize: selectedFile.size, 
        fileType: selectedFile.type, 
        ipfsUri: fileUri, 
        image: fileUri,
        tokenId: tokenId, 
        mintedAt: new Date().toISOString(), 
        owner: account.address,
        thumbnail: thumbnail 
      };
      onNftMinted(newNft);
      setCurrentStep(3);
      setSuccessData({ tokenId: newNft.tokenId, transactionHash: receipt.transactionHash });
      toast({ title: "Heirloom Archived Successfully! 🎉", description: `Token ID: ${newNft.tokenId}` });
      
      setIsProcessing(false);

    } catch (error) {
      console.error('Full Mint Error:', error);
      let errorMessage = "An unexpected error occurred. Please try again.";
      if (error && typeof error === 'object' && 'name' in error && error.name === 'TransactionError') {
          errorMessage = "Transaction failed. Please check your balance and network, then try again.";
      } else if (error && typeof error === 'object' && 'message' in error) {
        errorMessage = error.message;
      }
      toast({ title: "Archiving Failed", description: errorMessage, variant: "destructive" });
      setIsProcessing(false);
      setCurrentStep(0);
    }
  };

  const resetUploader = () => {
    setSelectedFile(null);
    setThumbnail(null);
    setSuccessData(null);
    setCurrentStep(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };
  
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard!" });
  };
  
  const renderContent = () => {
    if (successData) {
      return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-2xl space-y-6 text-center">
          <CheckCircle className="h-24 w-24 text-green-500 mx-auto" />
          <h3 className="text-3xl font-bold">Heirloom Archived!</h3>
          <p className="text-foreground/80">Your memory is now permanently stored on the blockchain.</p>
          <div className="bg-background border border-border rounded-lg p-4 space-y-3 text-left">
            <div className="flex justify-between items-center">
              <span className="font-semibold">Token ID:</span>
              <span className="font-mono text-primary">{successData.tokenId}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-semibold">Transaction Hash:</span>
              <div className="flex items-center space-x-2">
                <a href={`https://www.oklink.com/amoy/tx/${successData.transactionHash}`} target="_blank" rel="noopener noreferrer" className="font-mono text-primary truncate hover:underline" style={{maxWidth: '200px'}}>
                  {successData.transactionHash}
                </a>
                <Button variant="ghost" size="icon" onClick={() => copyToClipboard(successData.transactionHash)}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          <Button onClick={resetUploader} className="bg-secondary hover:bg-taupe-hover text-secondary-foreground px-8 py-3 text-lg font-semibold flex items-center space-x-2">
            <PlusCircle className="h-5 w-5" />
            <span>Archive Another</span>
          </Button>
        </motion.div>
      );
    }

    if (isProcessing) {
      // Processing steps UI... (same as before)
    }

    if (selectedFile) {
      return (
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-2xl space-y-6">
          <div className="flex items-center space-x-4 bg-background rounded-lg p-4 shadow-sm border border-border">
            {thumbnail ? <img src={thumbnail} alt="preview" className="w-16 h-16 object-cover rounded-md" /> : React.createElement(getFileIcon(selectedFile), { className: "h-10 w-10 text-primary" })}
            <div className="text-left flex-grow"><p className="font-medium text-foreground truncate">{selectedFile.name}</p><p className="text-sm text-foreground/60">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p></div>
            <button onClick={removeFile} className="p-2 hover:bg-background rounded-full"><X className="h-5 w-5 text-foreground/70" /></button>
          </div>
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-4"><p className="text-sm text-foreground/80"><strong>🔒 Gentle Notice:</strong> Your memories will be minted using a sponsored (gas-free) transaction on the Polygon Amoy Testnet. This action is irreversible.</p></div>
          <div className="flex justify-end">
            <Button onClick={confirmMint} disabled={!selectedFile || !account} className="bg-secondary hover:bg-taupe-hover text-secondary-foreground px-8 py-3 text-lg font-semibold flex items-center space-x-2">
              <CreditCard className="h-5 w-5" /><span>Mint Heirloom NFT</span>
            </Button>
          </div>
        </motion.div>
      );
    }

    return (
      <div className={`upload-zone w-full max-w-2xl h-80 relative rounded-xl p-8 text-center flex flex-col justify-center items-center transition-all border-2 border-dashed ${dragActive ? 'border-primary bg-primary/5' : 'border-secondary'}`} onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop}>
        <input ref={fileInputRef} type="file" onChange={handleFileInputChange} accept="image/*,video/*,audio/*,text/*,.pdf" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
        <Upload className="h-16 w-16 text-primary mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-foreground mb-2">Drop your memory here</h3>
        <p className="text-foreground/70 mb-4">or click to browse files</p>
        <p className="text-sm text-foreground/50">You have {user.mintsRemaining} free mints left.</p>
        {!hasMints && (
          <div className="absolute inset-0 bg-background/80 flex flex-col items-center justify-center backdrop-blur-sm">
              <Lock className="h-16 w-16 text-primary mx-auto mb-4"/>
              <h3 className="text-xl font-semibold text-foreground">Out of Free Mints</h3>
              <Button onClick={() => setShowMintLimitModal(true)} className="mt-4">Unlock More</Button>
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      <div className="flex flex-col h-full text-foreground p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold">Archive a New Heirloom</h2>
          <p className="text-foreground/70">Drag and drop a file or click to select.</p>
        </div>
        
        <div className="flex-grow flex flex-col items-center justify-center">
          {renderContent()}
        </div>
      </div>
      <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Heirloom Mint</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to use 1 free mint to create a permanent digital heirloom. This action is irreversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleMintNFT}>Proceed</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <MintLimitModal isOpen={showMintLimitModal} onClose={() => setShowMintLimitModal(false)} />
    </>
  );
};

export default UploadSection;
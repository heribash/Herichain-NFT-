import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Store, Info, Tag, ShoppingCart, Gavel, PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useActiveAccount } from 'thirdweb/react';

const resolveIpfsUri = (uri) => {
  if (!uri) return 'https://placehold.co/300x300?text=Heirloom';
  if (uri.startsWith('ipfs://')) {
    return `https://ipfs.io/ipfs/${uri.substring(7)}`;
  }
  return uri;
};


const ListingCard = ({ listing, index }) => {
  const { nft, price } = listing;
  const displayImage = resolveIpfsUri(nft.image || nft.thumbnail);

  const handleBuy = () => {
    toast({ title: "🚧 Buying feature is not fully implemented yet!", description: "You can request this in your next prompt! 🚀" });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-card rounded-xl shadow-lg flex flex-col overflow-hidden border border-border"
    >
      <div className="aspect-w-1 aspect-h-1 w-full bg-background">
        <img src={displayImage} alt={nft.title} className="w-full h-full object-cover" />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="font-bold text-lg text-foreground mb-1 truncate">{nft.title}</h3>
        <p className="text-sm text-foreground/70 mb-3 line-clamp-2 flex-grow">{nft.description || 'No description'}</p>
        <div className="flex items-center justify-between mt-auto pt-3 border-t border-border">
          <div className="flex items-center font-semibold text-primary">
            <Tag className="h-4 w-4 mr-2" />
            <span>{price} MATIC</span>
          </div>
          <Button size="sm" onClick={handleBuy}>
            <ShoppingCart className="h-4 w-4 mr-2" />
            Buy
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

const AuctionCard = ({ auction, index }) => {
    const { asset, buyoutCurrencyValue, minimumNextBid } = auction;
    const displayImage = resolveIpfsUri(asset.image);

    const handleBid = () => {
        toast({ title: "🚧 Bidding feature is not fully implemented yet!", description: "You can request this in your next prompt! 🚀" });
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-card rounded-xl shadow-lg flex flex-col overflow-hidden border border-border"
        >
            <div className="aspect-w-1 aspect-h-1 w-full bg-background">
                <img src={displayImage} alt={asset.name} className="w-full h-full object-cover" />
            </div>
            <div className="p-4 flex flex-col flex-grow">
                <h3 className="font-bold text-lg text-foreground mb-1 truncate">{asset.name}</h3>
                <p className="text-sm text-foreground/70 mb-2">Token ID: {asset.id.toString()}</p>
                <div className="text-xs text-foreground/80 mb-3">
                    <p>Ends in: {new Date(Number(auction.endTimeInSeconds) * 1000).toLocaleString()}</p>
                </div>
                <div className="flex items-center justify-between mt-auto pt-3 border-t border-border">
                    <div className="flex flex-col">
                        <span className="text-xs text-foreground/70">Current Bid</span>
                        <span className="font-semibold text-primary">{minimumNextBid.displayValue} {minimumNextBid.symbol}</span>
                    </div>
                    <Button size="sm" onClick={handleBid}>
                        <Gavel className="h-4 w-4 mr-2" />
                        Place Bid
                    </Button>
                </div>
            </div>
        </motion.div>
    );
};


const CreateAuctionForm = ({ onAuctionCreated, userNfts }) => {
    const [showForm, setShowForm] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [useReserve, setUseReserve] = useState(false);
    const [agreedToTerms, setAgreedToTerms] = useState(false);
    const [selectedCurrency, setSelectedCurrency] = useState('MATIC');
    
    const availableNfts = userNfts.filter(nft => !nft.isListed);

    const currencies = [
      { symbol: 'MATIC', name: 'Matic' },
      { symbol: 'USDC', name: 'USD Coin' },
      { symbol: 'DAI', name: 'Dai' },
      { symbol: 'ETH', name: 'Ethereum' },
    ];

    const handleSubmit = (e) => {
        e.preventDefault();
        
        if (!agreedToTerms) {
            toast({ title: "Terms Agreement Required", description: "You must agree to the terms and conditions to create an auction.", variant: "destructive" });
            return;
        }

        setIsSubmitting(true);
        toast({ title: "🚧 Auction creation is not fully implemented yet!", description: "Connect to a marketplace contract to enable this. 🚀" });
        setTimeout(() => {
            setIsSubmitting(false);
            setShowForm(false);
        }, 1500);
    };

    if (!showForm) {
        return (
            <div className="text-center">
                <Button onClick={() => setShowForm(true)} className="bg-[#D4AF37] hover:bg-[#b89b31] text-black">
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Create New Auction
                </Button>
            </div>
        );
    }
    
    return (
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="bg-gradient-to-br from-[#D4AF37]/10 via-transparent to-[#D4AF37]/10 border border-[#D4AF37]/50 rounded-xl p-6 mb-8 text-foreground">
            <form onSubmit={handleSubmit} className="space-y-4">
                <h3 className="text-2xl font-bold text-[#D4AF37]">Create a New Auction</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="nftId" className="block text-sm font-medium mb-1">NFT to Auction</label>
                        <select id="nftId" name="nftId" required className="w-full bg-background border border-[#D4AF37]/50 rounded-md px-3 py-2 text-foreground focus:ring-[#D4AF37] focus:border-[#D4AF37]">
                            {availableNfts.length > 0 ? (
                                <>
                                  <option value="">Select your Heirloom...</option>
                                  {availableNfts.map(nft => (
                                      <option key={nft.id.toString()} value={nft.tokenId}>
                                          ID: {nft.tokenId} - {nft.title}
                                      </option>
                                  ))}
                                </>
                            ) : (
                                <option value="" disabled>You have no unlisted Heirlooms</option>
                            )}
                        </select>
                    </div>
                     <div>
                        <label htmlFor="currency" className="block text-sm font-medium mb-1">Currency</label>
                        <select id="currency" name="currency" value={selectedCurrency} onChange={(e) => setSelectedCurrency(e.target.value)} required className="w-full bg-background border border-[#D4AF37]/50 rounded-md px-3 py-2 text-foreground focus:ring-[#D4AF37] focus:border-[#D4AF37]">
                            {currencies.map(currency => (
                                <option key={currency.symbol} value={currency.symbol}>
                                    {currency.name} ({currency.symbol})
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="startingBid" className="block text-sm font-medium mb-1">Starting Bid ({selectedCurrency})</label>
                        <input type="number" id="startingBid" name="startingBid" step="0.01" required className="w-full bg-background border border-[#D4AF37]/50 rounded-md px-3 py-2" placeholder="e.g., 10.5" />
                    </div>
                    <div>
                         <label htmlFor="minBidIncrement" className="block text-sm font-medium mb-1">Minimum Bid Increment ({selectedCurrency})</label>
                        <input type="number" id="minBidIncrement" name="minBidIncrement" step="0.01" required className="w-full bg-background border border-[#D4AF37]/50 rounded-md px-3 py-2" placeholder="e.g., 1.0" />
                    </div>
                    <div>
                        <label htmlFor="startTime" className="block text-sm font-medium mb-1">Auction Start Time</label>
                        <input type="datetime-local" id="startTime" name="startTime" required className="w-full bg-background border border-[#D4AF37]/50 rounded-md px-3 py-2" />
                    </div>
                    <div>
                        <label htmlFor="endTime" className="block text-sm font-medium mb-1">Auction End Time</label>
                        <input type="datetime-local" id="endTime" name="endTime" required className="w-full bg-background border border-[#D4AF37]/50 rounded-md px-3 py-2" />
                    </div>
                    <div className="flex items-end md:col-span-2">
                        <div className="flex items-center h-full space-x-2">
                           <input type="checkbox" id="reservePriceCheck" name="reservePriceCheck" className="h-4 w-4 rounded border-[#D4AF37]/50 text-[#D4AF37] focus:ring-[#D4AF37]" onChange={(e) => setUseReserve(e.target.checked)} />
                           <label htmlFor="reservePriceCheck" className="text-sm font-medium">Use Reserve Price?</label>
                        </div>
                    </div>
                    {useReserve && (
                         <motion.div initial={{opacity: 0, height: 0}} animate={{opacity: 1, height: 'auto'}} className="md:col-span-2">
                            <label htmlFor="reservePrice" className="block text-sm font-medium mb-1">Reserve Price ({selectedCurrency})</label>
                            <input type="number" id="reservePrice" name="reservePrice" step="0.01" className="w-full bg-background border border-[#D4AF37]/50 rounded-md px-3 py-2" placeholder="Bids below this won't win" />
                            <p className="text-xs text-foreground/70 mt-1">If the auction ends below this price, the sale will not complete.</p>
                        </motion.div>
                    )}
                </div>

                <div>
                    <label htmlFor="description" className="block text-sm font-medium mb-1">Auction Description</label>
                    <textarea id="description" name="description" rows="3" className="w-full bg-background border border-[#D4AF37]/50 rounded-md px-3 py-2" placeholder="Tell buyers about this heirloom..."></textarea>
                </div>
                
                 <div className="flex items-start space-x-3 pt-2">
                    <input type="checkbox" id="terms" name="terms" required className="mt-1 h-4 w-4 rounded border-[#D4AF37]/50 text-[#D4AF37] focus:ring-[#D4AF37]" onChange={(e) => setAgreedToTerms(e.target.checked)} />
                    <label htmlFor="terms" className="text-sm font-medium">I agree to a 1% Herichain commission deducted from the final sale price. All sales are final, and no disputes will be handled.</label>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                    <Button type="button" variant="ghost" className="hover:bg-white/10" onClick={() => setShowForm(false)} disabled={isSubmitting}>Cancel</Button>
                    <Button type="submit" disabled={isSubmitting || !agreedToTerms} className="bg-[#D4AF37] hover:bg-[#b89b31] text-black disabled:bg-[#d4af37]/50 disabled:cursor-not-allowed">
                        {isSubmitting ? "Creating..." : "Create Auction"}
                    </Button>
                </div>
            </form>
        </motion.div>
    );
};


const Marketplace = ({ listings, nfts }) => {
    const [auctions, setAuctions] = useState([]);

    useEffect(() => {
    }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="p-8"
    >
      <div className="flex items-center mb-6">
        <Store className="h-8 w-8 text-primary mr-4" />
        <h2 className="text-3xl font-bold text-foreground">Legacy Marketplace</h2>
      </div>
      
      <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 mb-8">
        <div className="flex items-start">
          <Info className="h-5 w-5 text-primary mr-3 mt-1 flex-shrink-0" />
          <div>
            <p className="font-semibold text-foreground">Welcome to the Marketplace!</p>
            <p className="text-sm text-foreground/80">
              Browse direct listings, participate in auctions, and acquire unique heirlooms. A platform fee applies to all sales.
            </p>
          </div>
        </div>
      </div>

       <div className="mb-12">
            <CreateAuctionForm 
                onAuctionCreated={(newAuction) => setAuctions([newAuction, ...auctions])} 
                userNfts={nfts} 
            />
        </div>

        {auctions && auctions.length > 0 && (
            <div className="mb-12">
                <h3 className="text-2xl font-bold text-foreground mb-6 flex items-center">
                    <Gavel className="h-6 w-6 mr-3 text-[#D4AF37]" /> Live Auctions
                </h3>
                <div className="grid gap-8" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))' }}>
                    {auctions.map((auction, index) => (
                        <AuctionCard key={auction.id} auction={auction} index={index} />
                    ))}
                </div>
            </div>
        )}

      {listings && listings.length > 0 && (
          <div className="mb-12">
              <h3 className="text-2xl font-bold text-foreground mb-6 flex items-center">
                  <Tag className="h-6 w-6 mr-3 text-primary" /> Direct Listings
              </h3>
              <div 
                className="grid gap-8"
                style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))' }}
              >
                {listings.map((listing, index) => (
                  <ListingCard key={listing.id} listing={listing} index={index} />
                ))}
              </div>
          </div>
      )}

      {(!listings || listings.length === 0) && (!auctions || auctions.length === 0) && (
        <div className="text-center py-12 px-6 bg-background rounded-xl border border-dashed border-border">
          <div className="w-24 h-24 bg-card rounded-full flex items-center justify-center mx-auto mb-6">
            <Store className="h-12 w-12 text-foreground/40" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">The Marketplace is Open</h3>
          <p className="text-foreground/70 mb-6">
            No heirlooms have been listed for sale or auction yet. Be the first!
          </p>
        </div>
      )}
    </motion.div>
  );
};

export default Marketplace;
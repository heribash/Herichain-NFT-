import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wallet, Globe, ExternalLink, Droplet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { useActiveAccount } from 'thirdweb/react';
import CreateInternalWallet from '@/components/CreateInternalWallet';

const WalletDashboard = ({ user, nfts }) => {
  const totalStorage = nfts.reduce((acc, nft) => acc + (nft.fileSize || 0), 0);
  const account = useActiveAccount();
  const walletAddress = account?.address;
  const [isFunding, setIsFunding] = useState(false);

  const handleViewOnPolygon = () => {
    if (walletAddress) {
      window.open(`https://www.oklink.com/amoy/address/${walletAddress}`, '_blank');
    } else {
      toast({ title: "Vault Not Connected", description: "Please connect your wallet first.", variant: "destructive" });
    }
  };

  const handleGetTestFunds = async () => {
    if (!walletAddress) {
      toast({ title: "Vault Not Connected", description: "Please connect your wallet first.", variant: "destructive" });
      return;
    }
    setIsFunding(true);
    toast({ title: "Faucet Information", description: "Please use a manual faucet like faucet.polygon.technology for Amoy testnet funds." });
    window.open('https://faucet.polygon.technology/', '_blank');
    setTimeout(() => setIsFunding(false), 3000);
  };

  const handleExportData = () => {
    toast({ title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" });
  };

  if (!walletAddress) {
    return <CreateInternalWallet user={user} />;
  }

  return (
    <div className="space-y-6 text-foreground">
      <div>
        <h2 className="text-2xl font-bold mb-2">Vault & Security</h2>
        <p className="text-foreground/70">Manage your digital archive and blockchain assets.</p>
      </div>

      <div className="bg-background rounded-xl p-6 border border-border">
        <h3 className="text-lg font-semibold mb-4">Connected Vault</h3>
        <div>
          <p className="text-sm text-foreground/70">Your connected vault address:</p>
          <p className="font-mono text-lg text-primary break-all">{walletAddress}</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="bg-secondary rounded-xl p-6 text-secondary-foreground">
          <div className="flex items-center justify-between mb-4"><Wallet className="h-8 w-8" /><span className="text-sm opacity-90">Total Heirlooms</span></div>
          <div><p className="text-3xl font-bold">{nfts.length}</p><p className="text-sm opacity-90">NFTs Archived</p></div>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }} className="bg-background rounded-xl p-6 border border-border">
          <div className="flex items-center justify-between mb-4"><Globe className="h-8 w-8 text-primary" /><span className="text-sm text-foreground/70">Storage Used</span></div>
          <div><p className="text-3xl font-bold text-foreground">{(totalStorage / 1024 / 1024).toFixed(1)}MB</p><p className="text-sm text-foreground/70">on IPFS</p></div>
        </motion.div>
      </div>

      <div className="bg-background rounded-xl p-6 border border-border">
        <h3 className="text-lg font-semibold mb-4">Vault Management</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <Button onClick={handleViewOnPolygon} variant="outline" className="justify-start h-auto p-4 border-primary text-primary hover:bg-primary hover:text-accent-foreground">
            <div className="flex items-center space-x-3"><ExternalLink className="h-6 w-6" /><div className="text-left"><p className="font-semibold">View on Explorer</p><p className="text-sm">Verify your transactions on the blockchain</p></div></div>
          </Button>
          <Button onClick={handleGetTestFunds} variant="outline" disabled={isFunding} className="justify-start h-auto p-4 border-primary text-primary hover:bg-primary hover:text-accent-foreground">
            <div className="flex items-center space-x-3">
              {isFunding ? <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div> : <Droplet className="h-6 w-6" />}
              <div className="text-left"><p className="font-semibold">Get Test Funds</p><p className="text-sm">Use a faucet for Amoy testnet POL</p></div>
            </div>
          </Button>
        </div>
      </div>

      <div className="bg-background rounded-xl p-6 border border-border">
        <h3 className="text-lg font-semibold mb-4">Data Management</h3>
        <div className="flex items-center justify-between">
          <div><p className="font-medium text-foreground">Export Your Data</p><p className="text-sm text-foreground/70">Download a backup of all your heirlooms and metadata</p></div>
          <Button onClick={handleExportData} variant="outline" className="border-primary text-primary hover:bg-primary hover:text-accent-foreground">Export Data</Button>
        </div>
      </div>
    </div>
  );
};

export default WalletDashboard;
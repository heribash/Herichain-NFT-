import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Upload, Gem, Settings, Store, Trophy, Globe, Loader, Gift } from 'lucide-react';
import UploadSection from '@/components/UploadSection';
import NFTGallery from '@/components/NFTGallery';
import WalletDashboard from '@/components/WalletDashboard';
import Marketplace from '@/components/Marketplace';
import MemoryChallenges from '@/components/MemoryChallenges';
import GlobalLegacyDay from '@/components/GlobalLegacyDay';
import Referrals from '@/components/Referrals'; // New component
import { useActiveAccount } from 'thirdweb/react';
import { getContract } from 'thirdweb';
import { getOwnedNFTs } from 'thirdweb/extensions/erc721';
import { client } from '@/main';
import { appConfig } from '@/config';
import { toast } from '@/components/ui/use-toast';

const Dashboard = ({ user, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState('upload');
  const [nfts, setNfts] = useState([]);
  const [isNftsLoading, setIsNftsLoading] = useState(true);
  const [listings, setListings] = useState([]);
  const account = useActiveAccount();

  useEffect(() => {
    const fetchNfts = async () => {
      if (!account?.address) {
        setIsNftsLoading(false);
        return;
      }
      setIsNftsLoading(true);
      try {
        const contract = getContract({ client, chain: appConfig.chain, address: appConfig.nftContractAddress });
        const ownedNfts = await getOwnedNFTs({ contract, owner: account.address });
        
        const formattedNfts = ownedNfts.map(nft => ({
          ...nft,
          tokenId: nft.id.toString(),
          title: nft.metadata.name || 'Untitled',
          isListed: false // This can be enhanced by checking marketplace listings
        })).sort((a, b) => Number(b.id) - Number(a.id));

        setNfts(formattedNfts);
      } catch (error) {
        console.error("Failed to fetch NFTs in Dashboard:", error);
        toast({ title: "Failed to fetch heirlooms", description: "Could not retrieve your heirlooms from the blockchain.", variant: "destructive" });
      } finally {
        setIsNftsLoading(false);
      }
    };

    fetchNfts();
  }, [account]);

  useEffect(() => {
    const savedListings = localStorage.getItem('herichain_listings');
    if (savedListings) {
      setListings(JSON.parse(savedListings));
    }
  }, []);

  const handleNftMinted = (newNft) => {
    const formattedNewNft = {
      ...newNft,
      id: BigInt(newNft.tokenId),
      metadata: newNft,
      tokenId: newNft.tokenId,
      title: newNft.name || 'Untitled',
      isListed: false,
    };
    setNfts(prevNfts => [formattedNewNft, ...prevNfts]);
    onUpdateUser({ mintsRemaining: user.mintsRemaining - 1 });
    setActiveTab('gallery');
  };

  const handleNftListed = (listing) => {
    const updatedListings = [listing, ...listings];
    setListings(updatedListings);
    localStorage.setItem('herichain_listings', JSON.stringify(updatedListings));
    
    const updatedNfts = nfts.map(nft => 
      nft.id.toString() === listing.nft.id ? { ...nft, isListed: true } : nft
    );
    setNfts(updatedNfts);
  };

  const tabs = [
    { id: 'upload', label: 'Archive Heirloom', icon: Upload },
    { id: 'gallery', label: 'My Heirlooms', icon: Gem },
    { id: 'marketplace', label: 'Legacy Marketplace', icon: Store },
    { id: 'referrals', label: 'Refer & Earn', icon: Gift },
    { id: 'challenges', label: 'Memory Challenges', icon: Trophy },
    { id: 'legacyday', label: 'Global Legacy Day', icon: Globe },
    { id: 'wallet', label: 'Vault & Settings', icon: Settings }
  ];

  return (
    <div className="min-h-screen bg-background pt-8 text-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-foreground">
            Welcome, {user.name}
          </h1>
          <p className="text-lg text-foreground/70 mt-2">
            Your family album awaits. You have {user.mintsRemaining} free mints remaining.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-12 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="lg:col-span-3"
          >
            <div className="bg-card/50 rounded-xl shadow-lg p-4 sticky top-24">
              <nav className="flex flex-col space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-3 px-4 py-3 font-medium rounded-lg transition-colors ${
                      activeTab === tab.id
                        ? 'text-secondary-foreground bg-secondary'
                        : 'text-foreground/70 hover:bg-card hover:text-foreground'
                    }`}
                  >
                    <tab.icon className="h-5 w-5" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-9"
          >
            <div className="bg-card/50 rounded-xl shadow-lg min-h-[600px] overflow-hidden">
               {isNftsLoading ? (
                 <div className="flex flex-col items-center justify-center text-center py-12 px-6 h-[600px]">
                   <Loader className="h-12 w-12 text-primary animate-spin mb-4" />
                   <h3 className="text-xl font-semibold text-foreground">Loading Your Vault...</h3>
                   <p className="text-foreground/70">Please wait while we fetch your heirlooms.</p>
                 </div>
               ) : (
                <>
                  {activeTab === 'upload' && (
                    <UploadSection user={user} onNftMinted={handleNftMinted} />
                  )}
                  {activeTab === 'gallery' && (
                    <NFTGallery 
                      nfts={nfts} 
                      setNfts={setNfts} 
                      onNftListed={handleNftListed}
                    />
                  )}
                  {activeTab === 'marketplace' && (
                    <Marketplace listings={listings} nfts={nfts} />
                  )}
                  {activeTab === 'referrals' && (
                    <Referrals user={user} />
                  )}
                  {activeTab === 'challenges' && (
                    <MemoryChallenges nfts={nfts} />
                  )}
                  {activeTab === 'legacyday' && (
                    <GlobalLegacyDay />
                  )}
                  {activeTab === 'wallet' && (
                    <div className="p-6">
                      <WalletDashboard user={user} nfts={nfts} />
                    </div>
                  )}
                </>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;